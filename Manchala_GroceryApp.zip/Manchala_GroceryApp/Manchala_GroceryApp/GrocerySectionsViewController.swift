//
//  ViewController.swift
//  Manchala_GroceryApp
//
//  Created by Manchala,Sarika on 4/12/22.
//

import UIKit
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return grocerysArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var c = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        c.textLabel?.text = grocerysArray[indexPath.row].section
        return c
    }
    
    var grocery = GrocerySections()
    
    var grocerysArray = grocerys
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Grocery Sections"
        // Do any additional setup after loading the view.
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemSegue"{
            let destination = segue.destination as! GroceryItemsViewController
            destination.items = grocerysArray[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]
        }
    }
    }

