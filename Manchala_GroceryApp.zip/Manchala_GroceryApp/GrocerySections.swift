//
//  GrocerySections.swift
//  Manchala_GroceryApp
//
//  Created by Manchala,Sarika on 4/12/22.
//

import Foundation

struct GrocerySections {
var section = ""
var items_Array:[GroceryItem] = []
}

struct GroceryItem{
    var itemName = ""
    var itemImage = ""
    var itemInfo = ""
}

let item1 = GrocerySections(section:"Flowers",items_Array:[GroceryItem(itemName:"Sun Flower",itemImage:"f1",itemInfo:"Sunflowers are usually tall annual or perennial plants that in some species can grow to a height of 300 centimetres (120 inches) or more. Each flower is actually a disc made up of tiny flowers, to form a larger false flower to better attract pollinators. The plants bear one or more wide, terminal capitula"),
                                                          GroceryItem(itemName:"Rose",itemImage:"f2",itemInfo:"A rose is a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars. "),
                                                          GroceryItem(itemName:"Lilly",itemImage:"f3",itemInfo:"Lilium is a genus of herbaceous flowering plants growing from bulbs, all with large prominent flowers. They are the true lilies."),
                                                          GroceryItem(itemName:"Lotus",itemImage:"f4",itemInfo:"Gold Splash Hibiscus Lotus has a double pink flower with variegated leaves lotus. this is the first variegated leaf lotus."),
                                                          GroceryItem(itemName:"Hibuscus",itemImage:"f5",itemInfo:"Nelumbo nucifera, also known as Indian lotus, sacred lotus, or simply lotus, is one of two extant species of aquatic plant in the family Nelumbonaceae.")] )

let item2 = GrocerySections( section: "Sweets", items_Array: [GroceryItem(itemName: "Laddo", itemImage: "s1", itemInfo: "Laddo is Indian sweet wich is very famous and in round                                                               shape"),
                                                             GroceryItem(itemName: "Kaja", itemImage: "s2", itemInfo: "Kaja is one of the juicy sweet in india and made in kakinda"),
                                                             GroceryItem(itemName: "Jilebhi", itemImage: "s3", itemInfo: "Jiledhi is very famous in north of india and it will in yellow and orange color"),
                                                             GroceryItem(itemName: "Mothichur", itemImage: "s4", itemInfo: "Mothichur is also one of the types of laddo and it is in round and yellow color"),
                                                             GroceryItem(itemName: "Putharekulu", itemImage: "s5", itemInfo: "Putharekulu is famous in andrapradesh and it is like paper ")] )

let item3 = GrocerySections( section: "Dryfruits", items_Array: [GroceryItem(itemName: "Badham", itemImage: "d1", itemInfo: "The almond is a species of tree native to Iran and surrounding countries and ancient remains of almonds were discovered in the Levant area. "),
                                                                GroceryItem(itemName: "Kaaju", itemImage: "d2", itemInfo: "Kaaju is rich in vitamins and potassium Cashews are a good source of copper, magnesium, phosphorus and zinc which are required for bone building."),
                                                                GroceryItem(itemName: "Kismis", itemImage: "d3", itemInfo: "Kismis is taken by people who have less blood levels"),
                                                                GroceryItem(itemName: "Pistha", itemImage: "d4", itemInfo: "Pistha is dryfruit which is salty and tasty and enjoyable"),
                                                                GroceryItem(itemName: "Apricot", itemImage: "d5", itemInfo: "Apricots are rich in ion and helps for hair growth")] )

let item4 = GrocerySections( section: "Chocolates", items_Array: [GroceryItem(itemName: "DairyMilk", itemImage: "c1", itemInfo: "Dairymilk is of cost accoring t the six of the                                                                        chocolate"),
                                                                 GroceryItem(itemName: "5Star", itemImage: "c2", itemInfo: "5star is of rice 5 rupees It is described as a caramel and nougat mix covered with smooth milk chocolate and is sold in a golden wrapper decorated with stars"),
                                                                 GroceryItem(itemName: "Kitkat", itemImage: "c3", itemInfo: "Kitkat is also very famous chocolate and taken by all people aorund the world"),
                                                                 GroceryItem(itemName: "Milkybar", itemImage: "c4", itemInfo: "Giant white chocolate buttons made from Milkybar chocolate. Perfect for sharing. No artificial colours, flavours of preservatives."),
                                                                 GroceryItem(itemName: "Snickers", itemImage: "c5", itemInfo: "Snickers is a chocolate bar made by the American company Mars, Incorporated, consisting of nougat topped with caramel and peanuts that has been enrobed in milk chocolate.")] )

let item5 = GrocerySections( section: "Icecreams", items_Array: [ GroceryItem(itemName: "Vanila", itemImage: "i1", itemInfo: "Vanilla is frequently used to flavor ice cream, especially in North America, Asia, and Europe. Vanilla ice cream, like other flavors of ice cream, was originally created by cooling"),
                                                                 GroceryItem(itemName: "Butterscotch", itemImage: "i2", itemInfo: "Rich, creamy real butterscotch ice cream is easy to make and you don't even need an ice cream maker. I'll show you how to freeze it without one!"),
                                                                 GroceryItem(itemName: "CookieandCream", itemImage: "i3", itemInfo: "Best ice cream sandwich, give us a try, you will be happy you did. Handcrafted & warm Ice Cream Sandwiches!"),
                                                                 GroceryItem(itemName: "Browniecream", itemImage: "i4", itemInfo: "This brownie ice cream is made with chunks of rich brownie swirled through vanilla ice cream. Because when it comes to dessert"),
                                                                 GroceryItem(itemName: "OreoCream", itemImage: "i5", itemInfo: "The full portfolio starts with its hero product, Oreo Ice Cream, which comes in 48 oz. and 14 oz. scoopable tubs that make it easy to enjoy")] )


let grocerys = [item1, item2, item3, item4, item5]

