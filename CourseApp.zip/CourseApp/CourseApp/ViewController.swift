//
//  ViewController.swift
//  CourseApp
//
//  Created by Manchala,Sarika on 2/10/22.
//

import UIKit

class ViewController: UIViewController {

  
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var crsNum: UILabel!
    
  
    @IBOutlet weak var crstit: UILabel!
    
    @IBOutlet weak var crsOffered: UILabel!
    
    
    @IBOutlet weak var previousButton: UIButton!
    
    
    @IBOutlet weak var nextButton: UIButton!
    
    let courses = [["img01","44555","NetworkSecurity","Fall2022"],["img02","44643","ios","Spring2022"],["img03","44656","Streaming data","Spring2022"]]
    var imageNumber = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateUI(imageNumber)
        previousButton.isEnabled = false;
    }
    

    @IBAction func previousButtonClicked(_ sender: UIButton) {
        
        nextButton.isEnabled = true;
        imageNumber = imageNumber-1;
        updateUI(imageNumber)
        if(imageNumber==0)
        {
            previousButton.isEnabled = false;
        }
       
    }
    
    @IBAction func nextButtonClicked(_ sender: UIButton) {
        imageNumber = imageNumber+1;
        updateUI(imageNumber)
        previousButton.isEnabled = true;
        if(imageNumber==courses.count-1)
        {
            nextButton.isEnabled = false;
        }
    }
    
    func updateUI(_ imageNumber:Int)
    {
        imageViewOutlet.image = UIImage(named: courses[imageNumber][0])
        crsNum.text = courses[imageNumber][1]
        crstit.text = courses[imageNumber][2]
        crsOffered.text = courses[imageNumber][3]
    }
}

