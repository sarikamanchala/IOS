//
//  ViewController.swift
//  HelloApp
//
//  Created by Manchala,Sarika on 1/20/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textOutlet: UITextField!
    @IBOutlet weak var displayLabel: UILabel!
    @IBOutlet weak var courseOutlet: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ButtonClicked(_ sender: UIButton) {
        var enteredName = textOutlet.text!
        var enteredCourse = courseOutlet.text!
        displayLabel.text = "Hello ,\(enteredName)! course is \(enteredCourse)"
    }
    
}

