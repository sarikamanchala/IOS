//
//  ViewController.swift
//  EvenOdd
//
//  Created by Manchala,Sarika on 2/8/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var intTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var resultLabel: UILabel!
    @IBAction func submitButton(_ sender: UIButton) {
        var input = Int(intTextField.text!)
        if(input!%2==0)
        {
            resultLabel.text =  "It is even: \(input!)"
        }
        else
        {
            resultLabel.text =  "It is Odd : \(input!)"
        }
    }
    
}

