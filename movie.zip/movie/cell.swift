import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var movieCollectionView: UIImageView!
    
    func assignMovie(with movie:Movies){
           movieCollectionView.image = movie.image
       }
}