//
//  ViewController.swift
//  Manchala_SearchApp
//
//  Created by Manchala,Sarika on 3/3/22.
//



import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchOption: UIButton!

    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var prevImage: UIButton!
    
    @IBOutlet weak var nextImage: UIButton!
    
    @IBOutlet weak var topicinfoText: UITextView!
    
    @IBOutlet weak var resetAction: UIButton!
    
    var imageNumber = 0;
    var topic: Int = -1
    var count1 : Int = -1
    var arr = [
        ["prabhas","milli","wills","sheldon","surya"],["sunflower","rose","lilly","lotus","tulip"],["dog","cat","monkey","panda","pig"]]
    
    var flower_keywords = ["flower","size","color","sunflower","rose","lilly","lotus","tulip"]
    var animal_keywords =
    ["scientific name","animal","lifespan","typeofanimal","dog","cat","monkey","panda","pig"]
    var actor_keywords = ["actor","actors","prabhas","milli","wills","sheldon","surya"]
    var topics_array = [["Hi this is Prabhas i did many telugu movies and i did great Pan india movie Bahubali","Milli here , i did Stranger Things in Netflix which is verey interesting and high rate series","Willi here i did many hollyhood movies and my fav is black mens","Sheldon here , i did The Big Bang Theory which is a sitcom and i kloved it","This is Surya from south Indian movies and my like doing movies"],
        ["This is Sunflower","This is a Rose","This is Lilly","This is Lotus","This is Tulip"],
        ["This is Dog","This is Cat","This is Monkey","This is Panda","This is Pig"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        searchOption.isEnabled = false
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetAction.isHidden = true
        resultImage.image = UIImage(named: "default")

        //On Loading the app we need to display default Image
    }


    @IBAction func searchFieldAction(_ sender: Any) {
        searchOption.isEnabled = true
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        if(actor_keywords.contains(searchTextField.text!)){
            topic = 0
            imageNumber = 0
            buttonsDisable()
        }
        else if(flower_keywords.contains(searchTextField.text!)){
            topic = 1
            imageNumber = 0
            buttonsDisable()
        }
        else if(animal_keywords.contains(searchTextField.text!)){
            topic = 2
            imageNumber = 0;
            buttonsDisable()
        }
        else{
            topic = -1
            resultImage.image = UIImage(named: "default")
            topicinfoText.text = "No matches with the given Key words. Please try again."
            resetAction.isHidden = true
            nextImage.isHidden = true
            prevImage.isHidden = true
        }
        
        if(topic != -1)
        {
            prevImage.isEnabled = false
            nextImage.isEnabled = true
            count1 = arr[topic].count
            resultImage.image = UIImage(named: arr[topic][0])
            topicinfoText.text = topics_array[topic][0]
        }
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
            nextImage.isEnabled = true;
            imageNumber -= 1
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicinfoText.text = topics_array[topic][imageNumber]
            if(imageNumber == 0){
                        prevImage.isEnabled = false
                }
    
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
            prevImage.isEnabled = true
            imageNumber += 1
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicinfoText.text = topics_array[topic][imageNumber]
            if(imageNumber == count1-1){
                nextImage.isEnabled = false
            }
    }
    
    @IBAction func resetButton(_ sender: Any) {
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetAction.isHidden = true
        searchTextField.text = ""
        searchOption.isEnabled = false
        topicinfoText.text = ""
        resultImage.image = UIImage(named: "default")
        
    }
    func buttonsDisable(){
        nextImage.isHidden = false
        prevImage.isHidden = false
        resetAction.isHidden = false
    }
    


}

