//
//  ViewController.swift
//  Manchala_Movies
//
//  Created by Manchala,Sarika on 4/21/22.
//

import UIKit

class GenreViewController: UIViewController {

    @IBOutlet weak var genreTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

