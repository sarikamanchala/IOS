//
//  ViewController.swift
//  StudentApp
//
//  Created by Manchala,Sarika on 3/24/22.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

