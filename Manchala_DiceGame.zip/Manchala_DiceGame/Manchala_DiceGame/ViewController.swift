//
//  ViewController.swift
//  Manchala_DiceGame
//
//  Created by Manchala,Sarika on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var player1Name: UITextField!
    
    
    @IBOutlet weak var player2Name: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var player1Label: UILabel!
    
    @IBOutlet weak var player2Label: UILabel!
    
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBAction func rollDiceButton(_ sender: UIButton) {
        let rand1 = Int.random(in: 1..<7)
        let rand2 = Int.random(in: 1..<7)
        var name1 = player1Name.text!
        var name2 = player2Name.text!
        player1Label.text = "\(name1)'s roll is : \(rand1)"
        player2Label.text = "\(name2)'s roll is : \(rand2)"
        if(rand1>rand2)
        {
            resultLabel.text = "\(name1) won the game"
        }
        else if(rand1<rand2)
        {
            resultLabel.text = "\(name2) won the game"
        }                   
        else
        {
            resultLabel.text = "The game is tie"
        }
    }
    
}

