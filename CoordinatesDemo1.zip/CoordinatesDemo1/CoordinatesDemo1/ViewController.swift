//
//  ViewController.swift
//  CoordinatesDemo1
//
//  Created by Manchala,Sarika on 3/1/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOutlet: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minx = imageViewOutlet.frame.minX;
        let miny = imageViewOutlet.frame.minY;
        print(minx,",",miny);
        let maxx = imageViewOutlet.frame.maxX;
        let maxy = imageViewOutlet.frame.maxY;
        print(maxx,",",maxy);
        let midx = imageViewOutlet.frame.midX;
        let midy = imageViewOutlet.frame.midY;
        print(midx,",",midy);
        
        imageViewOutlet.frame.origin.x = 0
        imageViewOutlet.frame.origin.y = 0
        
        imageViewOutlet.frame.origin.x = 314
        imageViewOutlet.frame.origin.y = 0
       
        imageViewOutlet.frame.origin.x = 0
        imageViewOutlet.frame.origin.y = 796
        
        imageViewOutlet.frame.origin.x = 314
        imageViewOutlet.frame.origin.y = 796
        
        
        imageViewOutlet.frame.origin.x = 157
        imageViewOutlet.frame.origin.y = 398

        
    }


}

