//
//  ViewController.swift
//  VowelTester
//
//  Created by Manchala,Sarika on 1/25/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textOutlet: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func testButton(_ sender: UIButton) {
        var input = textOutlet.text!
        if input.contains("a")||input.contains("e")||input.contains("i")||input.contains("o")||input.contains("u")
        {
            displayLabel.text = "the entered text has vowels"
        }
        else
        {
            displayLabel.text = "No vowels "
        }
    }
}

