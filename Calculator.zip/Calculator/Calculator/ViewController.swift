//
//  ViewController.swift
//  Calculator
//
//  Created by Manchala,Sarika on 1/27/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    var op1:Double = -1.1;
    var op2:Double = -1.1;
    var calcOperator:Character = " "
    var result:Double = -1.1;
    @IBAction func Button1(_ sender: UIButton) {
        displayOutlet.text = displayOutlet.text!+"1"
        if(op1 == -1.1)
        {
            op1 = 1
        }
        else{
            op2 = 1
        }
    }
    
    @IBAction func Button2(_ sender: UIButton) {
        displayOutlet.text = displayOutlet.text!+"2"
        if(op2 == -1.1 && op1 == -1.1)
        {
            op1 = 2
        }
        else{
            op2 = 2
        }
    }
    
    
    @IBAction func ButtonSum(_ sender: UIButton) {
        displayOutlet.text = displayOutlet.text!+"+"
        if calcOperator == " "
        {
            calcOperator = "+"
        }
    }
    
    @IBAction func ButtonMinus(_ sender: UIButton) {
        displayOutlet.text = displayOutlet.text!+"-"
        if calcOperator == " "
        {
            calcOperator = "-"
        }
    }
    
    @IBAction func ButtonEquals(_ sender: UIButton) {
        displayOutlet.text = displayOutlet.text!+"="
        if calcOperator == "+"
        {
            displayOutlet.text = displayOutlet.text!+"\(op1+op2)"
        }
        if calcOperator == "-"
        {
            displayOutlet.text = displayOutlet.text!+"\(op1-op2)"
        }
    }
    @IBAction func ButtonClear(_ sender: UIButton) {
        displayOutlet.text = " "
        
    }
}

