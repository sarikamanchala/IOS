//
//  ViewController.swift
//  Manchala_SearchApp
//
//  Created by Manchala,Shashankaravi on 3/1/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var imageName: UILabel!
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    @IBOutlet weak var prevButton: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    
    var topics_array = [["prabhas","milli","wills","sheldon","surya"],["sunflower","rose","lilly","lotus","tulip"],["dog","cat","monkey","panda","pig",],["bg","404"]]
    
    var actors_keywords = ["actor","actors","hero","cinema","prabhas","milli","wills","sheldon","surya","Celebrity"]
    
    var flower_keywords = ["flowers","flower","sunflower","rose","lilly","lotus","tulip"]
    
    var animals_keywords = ["animals","animal", "dog","cat","monkey","panda","pig"]
    
    var topic = 0
    var imag1:Int!
    var imag2:Int!
    var imag3:Int!
    var name1:Int!
    var name2:Int!
    var name3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
    
  
      
    @IBAction func searchTextField(_ sender: UITextField) {
        searchButton.isEnabled = true
        if(sender.text == ""){
           searchButton.isEnabled = false
            
        }
        else{
            prevButton.isEnabled = false
            nextButton.isEnabled = false
            searchButton.isEnabled = true
            resetButton.isHidden = false
    }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        prevButton.isHidden = true
        nextButton.isHidden = true
        searchButton.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: topics_array[3][0])
        topicInfoText.text = nil
        imageName.text = nil
    }
    
  
        
        
    
    
    var actor = [["prabhas","milli","wills","sheldon","surya"],[]]
    
    var flower = [["A Tale of Two Cities","The Hobbit","Harry Potter and the Philosopher's Stone","The Little Prince","Dream of the Red Chamber"],[]]

    var animal = [["African Bush Elephant","Black rhinoceros","African buffalo","Lion","Leopard"],[]]
    
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        prevButton.isHidden = false
        nextButton.isHidden = false
        prevButton.isEnabled = false
        nextButton.isEnabled = false
        resetButton.isEnabled = true
        if(actors_keywords.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: topics_array[0][imag1])
            imageName.text = actor[0][name1]
            topic = 1
            topicInfoText.text = actor[1][text1]
        }
        else if(flower_keywords.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: topics_array[1][imag2])
            imageName.text = flower[0][name2]
            topic = 2
            topicInfoText.text = flower[1][text2]
        }
        else if(animals_keywords.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: topics_array[2][imag3])
            imageName.text = flower[0][name3]
            topic = 3
            topicInfoText.text = animal[1][text3]
        }
        else{
            resultImage.image = UIImage(named: topics_array[3][1])
            topicInfoText.text = nil
            imageName.text = nil
            prevButton.isHidden = true
            nextButton.isHidden = true
            resetButton.isEnabled = true
        }
        
        
    }
    
    @IBAction func showPrevImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 -= 1
            name1 -= 1
            text1 -= 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 -= 1
            name2 -= 1
            text2 -= 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 -= 1
            name3 -= 1
            text3 -= 1
            dataUpdate(imgNo: imag3)
        }
        
    }
    
    @IBAction func showNextImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 += 1
            name1 += 1
            text1 += 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 += 1
            name2 += 1
            text2 += 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 += 1
            name3 += 1
            text3 += 1
            dataUpdate(imgNo: imag3)
        }
    }
    
    
    @IBAction func resetButton(_ sender: Any) {
        prevButton.isHidden = true
        nextButton.isHidden = true
        topicInfoText.text = nil
        imageName.text = nil
        searchTextField.text = nil
        resetButton.isHidden = true
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        topic = 0
        
        
    }
    
    func dataUpdate(imgNo: Int){
        if(topic == 1){
            if imag1 == topics_array[0].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[0][imag1])
                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][text1]
            }
            else if(imag1 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[0][imag1])
                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][text1]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[0][imag1])
                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][text1]
            }
        }
        if(topic == 2){
            if imag2 == topics_array[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[1][imag2])
                imageName.text = flower[0][name2]
                topicInfoText.text = flower[1][text2]
            }
            else if(imag2 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[1][imag2])
                imageName.text = flower[0][name2]
                topicInfoText.text = flower[1][text2]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[1][imag2])
                imageName.text = flower[0][name2]
                topicInfoText.text = flower[1][text2]
                
            }
        }
        if(topic == 3){
            if imag3 == topics_array[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[2][imag3])
                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][text3]
            }
            else if(imag3 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[2][imag3])
                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][text3]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: topics_array[2][imag3])
                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][text3]
                
            }
        }
    }
}




